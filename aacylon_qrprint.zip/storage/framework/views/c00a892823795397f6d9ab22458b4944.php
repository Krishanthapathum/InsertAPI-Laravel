<h3 class="mb-4 fw-bold text-center">All Generated QR Codes</h3>

<div class="row">
    <?php $__currentLoopData = $qrData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card shadow text-center">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($data['user']->first_names); ?> <?php echo e($data['user']->last_name); ?></h5>
                    <p class="card-text">International Permit No: <strong><?php echo e($data['user']->int_permit_no); ?></strong></p>
                    <p><a href="<?php echo e($data['url']); ?>" target="_blank" class="btn btn-outline-primary btn-sm">View Profile</a></p>
                    <div><?php echo $data['qr']; ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\User_Pathum\Projects\qr permit\dev\Newproject\newapp\resources\views/qr/generated.blade.php ENDPATH**/ ?>