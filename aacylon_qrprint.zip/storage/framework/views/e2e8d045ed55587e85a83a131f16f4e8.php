<?php $__env->startSection('content'); ?>

    <head>
        <link href="<?php echo e(asset('css/table.css')); ?>" rel="stylesheet">
    </head>

    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-3 compact-header">
            <h4 class="fw-bold">QR Code User List</h4>
            <div class="d-flex gap-2">
                <input type="text" id="searchBox" class="form-control form-control-sm" placeholder="Search...">
                <button id="printSelectedBtn" class="btn btn-sm btn-primary">Print</button>

            </div>
        </div>

        <table class="table table-custom" id="userTable">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll"></th>
                    <th>No</th>
                    <th>Name</th>
                    <th>SL License</th>
                    <th>INT Permit</th>
                    <th>Vehicle Type</th>
                    <th>Status</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" class="select-user" data-id="<?php echo e($user->id); ?>"></td>
                        <td><?php echo e(($users->currentPage() - 1) * $users->perPage() + $index + 1); ?></td>
                        <td><?php echo e($user->first_names); ?> <?php echo e($user->last_name); ?></td>
                        <td><?php echo e($user->sl_license_no); ?></td>
                        <td><?php echo e($user->int_permit_no); ?></td>
                        <td><?php echo e($user->vehicle_types); ?></td>
                        <td>
                            <?php if($user->qr_code_identifier): ?>
                                <span class="badge-status <?php echo e($user->printed ? 'badge-printed' : 'badge-generated'); ?>"
                                    id="status-<?php echo e($user->id); ?>">
                                    <?php echo e($user->printed ? 'Printed' : 'Generated'); ?>

                                </span>
                            <?php else: ?>
                                <span class="badge-status badge-pending">Pending</span>
                            <?php endif; ?>
                        </td>

                        <td class="text-center">
                            <?php if($user->qr_code_identifier): ?>
                                <button class="action-btn" data-bs-toggle="modal"
                                    data-bs-target="#qrModal<?php echo e($user->id); ?>" title="QR">
                                    <i class="bi bi-qr-code-scan"></i>
                                </button>
                                <button class="action-btn" data-bs-toggle="modal"
                                    data-bs-target="#profileModal<?php echo e($user->id); ?>" title="Profile">
                                    <i class="bi bi-person"></i>
                                </button>
                            <?php endif; ?>
                            <a href="#" class="action-btn" title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                        </td>
                    </tr>

                    <!-- QR Modal -->
                    <div class="modal fade" id="qrModal<?php echo e($user->id); ?>" tabindex="-1"
                        aria-labelledby="qrModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content text-center">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="qrModalLabel<?php echo e($user->id); ?>">QR Code -
                                        <?php echo e($user->first_names); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <?php echo QrCode::size(200)->generate(url('/user/' . $user->qr_code_identifier)); ?>

                                    <p class="mt-2 small text-muted"><?php echo e(url('/user/' . $user->qr_code_identifier)); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Profile Modal -->
                    <div class="modal fade" id="profileModal<?php echo e($user->id); ?>" tabindex="-1"
                        aria-labelledby="profileModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="profileModalLabel<?php echo e($user->id); ?>">User Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>Name:</strong> <?php echo e($user->first_names); ?> <?php echo e($user->last_name); ?></p>
                                    <p><strong>DOB:</strong> <?php echo e($user->dob); ?></p>
                                    <p><strong>SL License No:</strong> <?php echo e($user->sl_license_no); ?></p>
                                    <p><strong>INT Permit No:</strong> <?php echo e($user->int_permit_no); ?></p>
                                    <p><strong>Date Issued:</strong> <?php echo e($user->date_issued); ?></p>
                                    <p><strong>Expiry Date:</strong> <?php echo e($user->date_expiry); ?></p>
                                    <p><strong>Vehicle Types:</strong> <?php echo e($user->vehicle_types); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-3">
            <?php echo e($users->links('pagination::bootstrap-5')); ?>

        </div>
    </div>

    <div id="printContainer" style="display: none;"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('searchBox').addEventListener('input', function() {
                const value = this.value.toLowerCase();
                const rows = document.querySelectorAll('tbody tr');
                rows.forEach(row => {
                    const rowText = row.innerText.toLowerCase();
                    row.style.display = rowText.includes(value) ? '' : 'none';
                });
            });

            document.getElementById('selectAll').addEventListener('click', function() {
                const checkboxes = document.querySelectorAll('.select-user');
                checkboxes.forEach(cb => cb.checked = this.checked);
            });


        });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>


    <script>
        document.getElementById('printSelectedBtn').addEventListener('click', function() {
            const selectedIds = Array.from(document.querySelectorAll('.select-user:checked')).map(cb => cb.dataset
                .id);
            if (selectedIds.length === 0) {
                alert("Please select at least one user to print.");
                return;
            }

            const users = <?php echo json_encode($users->keyBy('id'), 15, 512) ?>;
            const printContainer = document.getElementById('printContainer');
            printContainer.innerHTML = ''; // Clear previous QR blocks

            selectedIds.forEach(id => {
                const user = users[id];
                if (!user.qr_code_identifier) return;

                const wrapper = document.createElement('div');
                wrapper.className = 'qr-block';
                wrapper.style.textAlign = 'center';
                wrapper.style.marginBottom = '30px';

                const qrDiv = document.createElement('div');
                qrDiv.id = `qrcode-${user.id}`;

                const permitP = document.createElement('p');
                permitP.innerHTML = `${user.int_permit_no}`;

                wrapper.appendChild(qrDiv);
                wrapper.appendChild(permitP);
                printContainer.appendChild(wrapper);

                new QRCode(qrDiv, {
                    text: `<?php echo e(url('/user')); ?>/` + user.qr_code_identifier,
                    width: 100,
                    height: 100
                });
            });

            setTimeout(() => {
                const printWindow = window.open('', '', 'width=600,height=800');
                printWindow.document.write(`
                        <html>
                        <head>
                            <title>Print QR Codes</title>
                            <style>
                                @page {
                                    size: 80mm auto;
                                    margin: 0;
                                }

                                @media print {
                                    html, body {
                                        width: 80mm;
                                        margin: 0;
                                        padding: 0;
                                    }
                                }

                                body {
                                    width: 80mm;
                                    margin: 0;
                                    padding: 0;
                                    font-family: Arial, sans-serif;
                                }

                                .qr-block {
                                    width: 100%;
                                    height: 100%;
                                    padding: 0px 0;
                                    display: flex;
                                    flex-direction: column;
                                    align-items: center;
                                    text-align: center;
                                    page-break-after: always;
                                }

                                .qr-block p {
                                    font-size: 12px;
                                    margin: 5px 0 0;
                                    word-break: break-word;
                                }

                                img {
                                    max-width: 100%;
                                }
                            </style>
                        </head>
                        <body>${printContainer.innerHTML}</body>
                        </html>
                    `);

                printWindow.document.close();
                printWindow.focus();

                // Wait to ensure all QR codes load
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 1500);
            }, 1000);

            // ✅ 1. Update UI badges
            selectedIds.forEach(id => {
                const badge = document.getElementById('status-' + id);
                if (badge) {
                    badge.innerText = 'Printed';
                    badge.classList.remove('badge-generated');
                    badge.classList.add('badge-printed');
                }
            });

            // ✅ 2. Send AJAX request to backend to update DB
            fetch("<?php echo e(route('qr.markAsPrinted')); ?>", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                    },
                    body: JSON.stringify({
                        ids: selectedIds
                    })
                })
                .then(res => res.json())
                .then(data => {
                    console.log('Marked as printed:', data);
                });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\User_Pathum\Projects\qr permit\dev\Newproject\newapp\resources\views/qr/index.blade.php ENDPATH**/ ?>